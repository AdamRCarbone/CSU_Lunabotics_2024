*********
  C API
*********

Pygame C API
============

.. toctree::
   :maxdepth: 1
   :glob:

   c_api/*
